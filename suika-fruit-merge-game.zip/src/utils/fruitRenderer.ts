import { FruitConfig } from '../types';

export function drawFruitOnCanvas(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  angle: number,
  fruit: FruitConfig,
  scale: number = 1
) {
  ctx.save();
  ctx.translate(x, y);

  // Scale transform
  ctx.scale(scale, scale);

  // 1. Soft Ambient Drop Shadow
  ctx.shadowColor = 'rgba(15, 23, 42, 0.22)';
  ctx.shadowBlur = 12 * scale;
  ctx.shadowOffsetY = 6 * scale;

  // 2. Base Fruit Sphere with 3D Radial Shading
  const grad = ctx.createRadialGradient(
    -radius * 0.35,
    -radius * 0.35,
    radius * 0.05,
    0,
    0,
    radius
  );
  grad.addColorStop(0, fruit.secondaryColor);
  grad.addColorStop(0.55, fruit.color);
  grad.addColorStop(0.92, fruit.darkColor);
  grad.addColorStop(1, '#1E112A');

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();

  // Reset drop shadow for crisp internal drawings
  ctx.shadowColor = 'transparent';

  // 3. Inner 3D Rim Light (Bounce Light at Bottom Right)
  const rimGrad = ctx.createRadialGradient(
    radius * 0.4,
    radius * 0.4,
    radius * 0.1,
    radius * 0.4,
    radius * 0.4,
    radius * 0.6
  );
  rimGrad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
  rimGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = rimGrad;
  ctx.fill();

  // Rotated Layer for body features (stripes, leaves, crowns)
  ctx.save();
  ctx.rotate(angle);

  // 4. Per-Fruit Specific Details
  drawFruitFeatures(ctx, radius, fruit);

  ctx.restore();

  // 5. Specular High-Gloss Highlights (Glossy 3D Toy/Jelly Look)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
  ctx.beginPath();
  ctx.ellipse(-radius * 0.38, -radius * 0.38, radius * 0.3, radius * 0.16, -Math.PI / 4, 0, Math.PI * 2);
  ctx.fill();

  // Secondary small glossy reflection dot
  ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.beginPath();
  ctx.arc(-radius * 0.22, -radius * 0.52, radius * 0.08, 0, Math.PI * 2);
  ctx.fill();

  // 6. Upright Kawaii Face (Keep face upright or slightly tilted for maximum readability)
  ctx.save();
  // Clamp face tilt to stay upright and readable
  const faceAngle = angle * 0.2;
  ctx.rotate(faceAngle);
  drawKawaiiFace(ctx, radius, fruit.faceType);
  ctx.restore();

  ctx.restore();
}

function drawFruitFeatures(ctx: CanvasRenderingContext2D, radius: number, fruit: FruitConfig) {
  const feat = fruit.features;

  // Watermelon Jagged Dark Green Stripes
  if (feat?.hasStripes) {
    ctx.strokeStyle = fruit.darkColor;
    ctx.lineWidth = radius * 0.18;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const stripeAngles = [-Math.PI * 0.6, -Math.PI * 0.2, Math.PI * 0.2, Math.PI * 0.6];
    stripeAngles.forEach((a) => {
      ctx.beginPath();
      const rInner = radius * 0.2;
      const rOuter = radius * 0.92;
      ctx.moveTo(Math.cos(a) * rInner, Math.sin(a) * rInner);
      ctx.quadraticCurveTo(
        Math.cos(a + 0.15) * (radius * 0.55),
        Math.sin(a + 0.15) * (radius * 0.55),
        Math.cos(a) * rOuter,
        Math.sin(a) * rOuter
      );
      ctx.stroke();
    });
  }

  // Pineapple Cross-Hatch Diamond Pattern
  if (fruit.tier === 9) {
    ctx.strokeStyle = 'rgba(217, 119, 6, 0.4)';
    ctx.lineWidth = radius * 0.08;
    for (let i = -radius * 0.7; i <= radius * 0.7; i += radius * 0.35) {
      ctx.beginPath();
      ctx.moveTo(i, -radius * 0.7);
      ctx.lineTo(i + radius * 0.6, radius * 0.7);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(i, radius * 0.7);
      ctx.lineTo(i + radius * 0.6, -radius * 0.7);
      ctx.stroke();
    }
  }

  // Dragon Fruit Green Scale Tips
  if (fruit.tier === 8) {
    ctx.fillStyle = '#4ADE80';
    ctx.strokeStyle = '#15803D';
    ctx.lineWidth = 1.5;
    const scaleAngles = [0, Math.PI * 0.4, Math.PI * 0.8, Math.PI * 1.2, Math.PI * 1.6];
    scaleAngles.forEach((sa) => {
      ctx.beginPath();
      const sx = Math.cos(sa) * (radius * 0.82);
      const sy = Math.sin(sa) * (radius * 0.82);
      ctx.arc(sx, sy, radius * 0.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    });
  }

  // Coconut Texture Dots / Fibers
  if (fruit.tier === 7) {
    ctx.fillStyle = 'rgba(67, 20, 7, 0.3)';
    for (let i = 0; i < 10; i++) {
      const da = (i / 10) * Math.PI * 2;
      const dr = radius * 0.65;
      ctx.beginPath();
      ctx.arc(Math.cos(da) * dr, Math.sin(da) * dr, radius * 0.05, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Mandarin Dimpled Skin Texture
  if (fruit.tier === 4) {
    ctx.fillStyle = 'rgba(194, 65, 12, 0.2)';
    for (let i = 0; i < 8; i++) {
      const da = (i / 8) * Math.PI * 2 + 0.2;
      const dr = radius * 0.5;
      ctx.beginPath();
      ctx.arc(Math.cos(da) * dr, Math.sin(da) * dr, radius * 0.04, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Crown (Pineapple or Blueberry)
  if (feat?.hasCrown) {
    ctx.fillStyle = fruit.tier === 9 ? '#16A34A' : fruit.darkColor;
    ctx.strokeStyle = '#14532D';
    ctx.lineWidth = 1;
    ctx.beginPath();
    const crownY = -radius * 0.92;
    ctx.moveTo(-radius * 0.35, crownY);
    ctx.lineTo(-radius * 0.45, crownY - radius * 0.4);
    ctx.lineTo(-radius * 0.18, crownY - radius * 0.18);
    ctx.lineTo(0, crownY - radius * 0.5);
    ctx.lineTo(radius * 0.18, crownY - radius * 0.18);
    ctx.lineTo(radius * 0.45, crownY - radius * 0.4);
    ctx.lineTo(radius * 0.35, crownY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Stem
  if (feat?.hasStem) {
    ctx.strokeStyle = '#78350F';
    ctx.lineWidth = Math.max(2.5, radius * 0.09);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, -radius * 0.88);
    ctx.quadraticCurveTo(radius * 0.2, -radius * 1.15, radius * 0.12, -radius * 1.28);
    ctx.stroke();
  }

  // Leaf
  if (feat?.hasLeaves) {
    ctx.fillStyle = '#22C55E';
    ctx.strokeStyle = '#15803D';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(radius * 0.28, -radius * 0.98, radius * 0.25, radius * 0.13, Math.PI / 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
}

function drawKawaiiFace(ctx: CanvasRenderingContext2D, radius: number, faceType: string) {
  const eyeDistance = radius * 0.33;
  const eyeY = -radius * 0.06;
  const eyeSize = Math.max(2.8, radius * 0.12);

  ctx.fillStyle = '#1E1B4B';
  ctx.strokeStyle = '#1E1B4B';
  ctx.lineWidth = Math.max(2, radius * 0.075);
  ctx.lineCap = 'round';

  // Pink Cheeks for all faces
  ctx.fillStyle = 'rgba(244, 63, 94, 0.45)';
  ctx.beginPath();
  ctx.ellipse(-eyeDistance * 1.35, eyeY + radius * 0.16, eyeSize * 0.9, eyeSize * 0.55, 0, 0, Math.PI * 2);
  ctx.ellipse(eyeDistance * 1.35, eyeY + radius * 0.16, eyeSize * 0.9, eyeSize * 0.55, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#1E1B4B';

  switch (faceType) {
    case 'cherry': {
      // Anime eyes with highlights
      [-eyeDistance, eyeDistance].forEach((ex) => {
        ctx.beginPath();
        ctx.arc(ex, eyeY, eyeSize, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ex - eyeSize * 0.3, eyeY - eyeSize * 0.3, eyeSize * 0.4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#1E1B4B';
      });

      // Cute smile
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.08, radius * 0.14, 0.2, Math.PI - 0.2);
      ctx.stroke();
      break;
    }
    case 'happy': {
      // Curved happy eyes ^_^
      ctx.beginPath();
      ctx.arc(-eyeDistance, eyeY + eyeSize * 0.2, eyeSize * 1.1, Math.PI * 1.1, Math.PI * 1.9);
      ctx.arc(eyeDistance, eyeY + eyeSize * 0.2, eyeSize * 1.1, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();

      // Big open smile
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.1, radius * 0.18, 0, Math.PI);
      ctx.fillStyle = '#EF4444';
      ctx.fill();
      ctx.stroke();
      break;
    }
    case 'wink': {
      // Left eye open anime, right eye winking line
      ctx.beginPath();
      ctx.arc(-eyeDistance, eyeY, eyeSize * 1.1, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(-eyeDistance - eyeSize * 0.3, eyeY - eyeSize * 0.3, eyeSize * 0.4, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.moveTo(eyeDistance - eyeSize * 1.1, eyeY);
      ctx.lineTo(eyeDistance + eyeSize * 1.1, eyeY);
      ctx.stroke();

      // Licking tongue mouth
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.1, radius * 0.14, 0, Math.PI);
      ctx.fillStyle = '#F43F5E';
      ctx.fill();
      ctx.stroke();
      break;
    }
    case 'cute': {
      // Big shiny sparkling anime eyes
      [-eyeDistance, eyeDistance].forEach((ex) => {
        ctx.beginPath();
        ctx.arc(ex, eyeY, eyeSize * 1.25, 0, Math.PI * 2);
        ctx.fillStyle = '#1E1B4B';
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ex - eyeSize * 0.35, eyeY - eyeSize * 0.35, eyeSize * 0.5, 0, Math.PI * 2);
        ctx.arc(ex + eyeSize * 0.25, eyeY + eyeSize * 0.25, eyeSize * 0.2, 0, Math.PI * 2);
        ctx.fill();
      });

      // W-shaped cute cat mouth
      ctx.strokeStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.arc(-radius * 0.07, eyeY + radius * 0.16, radius * 0.08, 0, Math.PI * 0.85);
      ctx.arc(radius * 0.07, eyeY + radius * 0.16, radius * 0.08, 0.15, Math.PI);
      ctx.stroke();
      break;
    }
    case 'cool': {
      // Black Sunglasses!
      ctx.fillStyle = '#0F172A';
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 2;

      ctx.beginPath();
      ctx.roundRect(-eyeDistance * 1.6, eyeY - eyeSize * 0.8, eyeDistance * 1.3, eyeSize * 1.8, 4);
      ctx.roundRect(eyeDistance * 0.3, eyeY - eyeSize * 0.8, eyeDistance * 1.3, eyeSize * 1.8, 4);
      ctx.fill();
      ctx.stroke();

      // Glasses bridge
      ctx.beginPath();
      ctx.moveTo(-eyeDistance * 0.3, eyeY - eyeSize * 0.3);
      ctx.lineTo(eyeDistance * 0.3, eyeY - eyeSize * 0.3);
      ctx.stroke();

      // Smirk
      ctx.beginPath();
      ctx.arc(radius * 0.05, eyeY + radius * 0.2, radius * 0.12, 0.1, Math.PI * 0.8);
      ctx.stroke();
      break;
    }
    case 'surprised': {
      // Big round eyes + O mouth
      [-eyeDistance, eyeDistance].forEach((ex) => {
        ctx.beginPath();
        ctx.arc(ex, eyeY, eyeSize * 1.2, 0, Math.PI * 2);
        ctx.fillStyle = '#1E1B4B';
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ex - eyeSize * 0.3, eyeY - eyeSize * 0.3, eyeSize * 0.45, 0, Math.PI * 2);
        ctx.fill();
      });

      // O mouth
      ctx.strokeStyle = '#1E1B4B';
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.ellipse(0, eyeY + radius * 0.18, radius * 0.09, radius * 0.14, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      break;
    }
    case 'star_eyes': {
      // Gold Star Eyes
      [-eyeDistance, eyeDistance].forEach((ex) => {
        drawStar(ctx, ex, eyeY, 5, eyeSize * 1.5, eyeSize * 0.7, '#F59E0B');
      });

      // Big happy smile
      ctx.strokeStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.1, radius * 0.2, 0, Math.PI);
      ctx.stroke();
      break;
    }
    case 'king': {
      // Shiny eyes + Crown + Royal smile
      [-eyeDistance, eyeDistance].forEach((ex) => {
        ctx.beginPath();
        ctx.arc(ex, eyeY, eyeSize * 1.3, 0, Math.PI * 2);
        ctx.fillStyle = '#1E1B4B';
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ex - eyeSize * 0.35, eyeY - eyeSize * 0.35, eyeSize * 0.5, 0, Math.PI * 2);
        ctx.fill();
      });

      // Proud open smile
      ctx.strokeStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.12, radius * 0.22, 0, Math.PI);
      ctx.fillStyle = '#EF4444';
      ctx.fill();
      ctx.stroke();

      // Gold Crown on top with jewels
      ctx.fillStyle = '#F59E0B';
      ctx.strokeStyle = '#B45309';
      ctx.lineWidth = 2;
      ctx.beginPath();
      const crownY = -radius * 0.84;
      ctx.moveTo(-radius * 0.38, crownY);
      ctx.lineTo(-radius * 0.45, crownY - radius * 0.38);
      ctx.lineTo(-radius * 0.2, crownY - radius * 0.2);
      ctx.lineTo(0, crownY - radius * 0.48);
      ctx.lineTo(radius * 0.2, crownY - radius * 0.2);
      ctx.lineTo(radius * 0.45, crownY - radius * 0.38);
      ctx.lineTo(radius * 0.38, crownY);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Crown Ruby Jewel
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(0, crownY - radius * 0.25, radius * 0.08, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    default: {
      // Standard cute anime face
      [-eyeDistance, eyeDistance].forEach((ex) => {
        ctx.beginPath();
        ctx.arc(ex, eyeY, eyeSize, 0, Math.PI * 2);
        ctx.fillStyle = '#1E1B4B';
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(ex - eyeSize * 0.3, eyeY - eyeSize * 0.3, eyeSize * 0.4, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.strokeStyle = '#1E1B4B';
      ctx.beginPath();
      ctx.arc(0, eyeY + radius * 0.08, radius * 0.14, 0, Math.PI);
      ctx.stroke();
      break;
    }
  }
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number,
  color: string
) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

