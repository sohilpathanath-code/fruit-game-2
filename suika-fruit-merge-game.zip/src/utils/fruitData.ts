import { FruitConfig } from '../types';

export const FRUIT_TIERS: FruitConfig[] = [
  {
    tier: 1,
    name: 'Cherry',
    radius: 15,
    points: 2,
    color: '#FF3B5C',
    secondaryColor: '#FF6B8B',
    darkColor: '#B3002D',
    faceType: 'cherry',
    features: { hasStem: true, hasLeaves: true }
  },
  {
    tier: 2,
    name: 'Grape',
    radius: 21,
    points: 4,
    color: '#A044FF',
    secondaryColor: '#C471ED',
    darkColor: '#6B11B0',
    faceType: 'happy',
    features: { hasStem: true }
  },
  {
    tier: 3,
    name: 'Blueberry',
    radius: 28,
    points: 8,
    color: '#3A7BD5',
    secondaryColor: '#3A96D5',
    darkColor: '#1A498A',
    faceType: 'cute',
    features: { hasCrown: true }
  },
  {
    tier: 4,
    name: 'Mandarin',
    radius: 36,
    points: 16,
    color: '#FF9233',
    secondaryColor: '#FFB366',
    darkColor: '#CC6600',
    faceType: 'wink',
    features: { hasTextureDots: true, hasStem: true }
  },
  {
    tier: 5,
    name: 'Green Apple',
    radius: 46,
    points: 32,
    color: '#70E000',
    secondaryColor: '#9EF01A',
    darkColor: '#38B000',
    faceType: 'yummy',
    features: { hasStem: true, hasLeaves: true }
  },
  {
    tier: 6,
    name: 'Peach',
    radius: 57,
    points: 64,
    color: '#FF85A1',
    secondaryColor: '#FFB3C6',
    darkColor: '#C94060',
    faceType: 'surprised',
    features: { hasStem: true, hasLeaves: true }
  },
  {
    tier: 7,
    name: 'Coconut',
    radius: 69,
    points: 128,
    color: '#8B5A2B',
    secondaryColor: '#A06D3B',
    darkColor: '#5C3818',
    faceType: 'cool',
    features: { hasTextureDots: true }
  },
  {
    tier: 8,
    name: 'Dragon Fruit',
    radius: 82,
    points: 256,
    color: '#FF007F',
    secondaryColor: '#FF66B2',
    darkColor: '#99004C',
    faceType: 'big_eyes',
    features: { hasSeeds: true, hasLeaves: true }
  },
  {
    tier: 9,
    name: 'Pineapple',
    radius: 96,
    points: 512,
    color: '#FFC107',
    secondaryColor: '#FFD54F',
    darkColor: '#FF8F00',
    faceType: 'star_eyes',
    features: { hasCrown: true, hasTextureDots: true }
  },
  {
    tier: 10,
    name: 'Watermelon',
    radius: 112,
    points: 1024,
    color: '#2EC4B6',
    secondaryColor: '#CBF3F0',
    darkColor: '#0F7173',
    faceType: 'king',
    features: { hasStripes: true, hasSeeds: true }
  }
];

export function getFruitByTier(tier: number): FruitConfig {
  const found = FRUIT_TIERS.find((f) => f.tier === tier);
  return found || FRUIT_TIERS[0];
}

export function getRandomSpawnTier(): number {
  // Spawns tiers 1 to 4 with weighted probability (Cherries & Grapes most common)
  const rand = Math.random();
  if (rand < 0.45) return 1; // Cherry
  if (rand < 0.75) return 2; // Grape
  if (rand < 0.90) return 3; // Blueberry
  return 4;                  // Mandarin
}
