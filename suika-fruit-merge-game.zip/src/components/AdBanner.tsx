import React from 'react';

interface AdBannerProps {
  position: 'top' | 'bottom';
  adSlotId?: string;
}

export const AdBanner: React.FC<AdBannerProps> = ({ position, adSlotId = 'ca-app-pub-7810800944989675/2554860150' }) => {
  return (
    <div className={`w-full max-w-xl mx-auto my-1 flex justify-center items-center ${position === 'top' ? 'mb-1' : 'mt-2'}`}>
      <div
        className="w-full bg-slate-900/90 text-white rounded-2xl p-2 border border-slate-700/80 shadow-md flex items-center justify-between gap-2 overflow-hidden relative"
        style={{ minHeight: '52px' }}
      >
        {/* AdMob Badge */}
        <div className="flex items-center gap-2">
          <span className="bg-amber-400 text-slate-900 text-[10px] font-black px-1.5 py-0.5 rounded tracking-wider uppercase">
            AdMob
          </span>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold text-slate-200">Sponsored Ad Space</span>
            <span className="text-[10px] text-slate-400 font-mono">Slot: {adSlotId.slice(0, 18)}...</span>
          </div>
        </div>

        {/* Ad CTA Simulation */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-emerald-400 hidden sm:inline">🍉 Suika Games & App Deals</span>
          <button
            onClick={() => window.open('https://google.com', '_blank')}
            className="bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-extrabold px-3 py-1 rounded-xl shadow transition-all cursor-pointer"
            id={`btn-admob-banner-${position}`}
          >
            Install / Play
          </button>
        </div>

        {/* Subtle Ad indicator dot */}
        <span className="absolute top-1 right-2 text-[8px] text-slate-500 font-bold uppercase">Ad</span>
      </div>
    </div>
  );
};
