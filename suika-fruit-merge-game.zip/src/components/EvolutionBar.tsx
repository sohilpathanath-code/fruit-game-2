import React from 'react';
import { FRUIT_TIERS } from '../utils/fruitData';
import { ChevronRight } from 'lucide-react';

interface EvolutionBarProps {
  currentDropTier: number;
}

export const EvolutionBar: React.FC<EvolutionBarProps> = ({ currentDropTier }) => {
  return (
    <div className="w-full max-w-xl mx-auto px-3 py-2 bg-white/80 backdrop-blur-md rounded-2xl border border-purple-100 shadow-sm select-none">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-600 flex items-center gap-1">
          <span>Evolution Chain</span>
          <ChevronRight className="w-3 h-3 text-indigo-400" />
        </span>
        <span className="text-[10px] text-slate-500 font-medium">Merge matching fruits to level up!</span>
      </div>

      <div className="flex items-center justify-between gap-1 overflow-x-auto py-1 px-1 no-scrollbar">
        {FRUIT_TIERS.map((fruit, index) => {
          const isCurrentReady = fruit.tier === currentDropTier;
          return (
            <React.Fragment key={fruit.tier}>
              <div
                className={`flex flex-col items-center flex-shrink-0 transition-all p-1 rounded-xl ${
                  isCurrentReady ? 'bg-indigo-100/80 scale-110 ring-2 ring-indigo-400' : 'hover:bg-slate-50'
                }`}
                title={`${fruit.name} (+${fruit.points} pts)`}
              >
                {/* Fruit circle representation */}
                <div
                  className="rounded-full shadow-sm flex items-center justify-center font-bold text-[9px] text-white transition-transform"
                  style={{
                    width: `${Math.max(16, Math.min(28, fruit.radius * 0.28))}px`,
                    height: `${Math.max(16, Math.min(28, fruit.radius * 0.28))}px`,
                    backgroundColor: fruit.color,
                    boxShadow: `0 2px 4px ${fruit.darkColor}40`
                  }}
                >
                  {fruit.tier}
                </div>
                <span className="text-[9px] font-bold text-slate-700 mt-1 truncate max-w-[42px] text-center">
                  {fruit.name}
                </span>
                <span className="text-[8px] font-semibold text-indigo-500">+{fruit.points}</span>
              </div>

              {index < FRUIT_TIERS.length - 1 && (
                <span className="text-slate-300 text-[10px] font-bold flex-shrink-0">›</span>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
