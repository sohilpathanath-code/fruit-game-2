import React, { useEffect, useRef, useState, useCallback } from 'react';
import Matter from 'matter-js';
import { PowerUpType, Particle, FloatingText } from '../types';
import { getFruitByTier, getRandomSpawnTier } from '../utils/fruitData';
import { drawFruitOnCanvas } from '../utils/fruitRenderer';
import { soundManager } from '../utils/audio';

interface FruitCanvasProps {
  currentTier: number;
  nextTier: number;
  onDropDone: (newNextTier: number) => void;
  onAddScore: (points: number, tierMerged: number) => void;
  onWatermelonCreated: () => void;
  onGameOver: () => void;
  activePowerUp: PowerUpType;
  onConsumePowerUp: (type: PowerUpType) => void;
  shakeTrigger: number;
  clearHalfTrigger?: number;
  onTriggerAdRescue?: () => void;
  isGameOver: boolean;
}

const CONTAINER_WIDTH = 380;
const CONTAINER_HEIGHT = 500;
const DANGER_Y = 85;
const HOLDER_Y = 35;

export const FruitCanvas: React.FC<FruitCanvasProps> = ({
  currentTier,
  onDropDone,
  onAddScore,
  onWatermelonCreated,
  onGameOver,
  activePowerUp,
  onConsumePowerUp,
  shakeTrigger,
  clearHalfTrigger = 0,
  onTriggerAdRescue,
  isGameOver
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Matter.js references
  const engineRef = useRef<Matter.Engine | null>(null);
  const worldRef = useRef<Matter.World | null>(null);

  // Game state refs
  const [pointerX, setPointerX] = useState<number>(CONTAINER_WIDTH / 2);
  const [isCooldown, setIsCooldown] = useState<boolean>(false);
  const [dangerWarning, setDangerWarning] = useState<boolean>(false);

  // Particles & Floating text
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const dangerStartTimeRef = useRef<number | null>(null);

  // Handle Clear 50% Fruits via Ad Trigger
  useEffect(() => {
    if (clearHalfTrigger > 0 && worldRef.current) {
      soundManager.playBomb();
      const bodies = Matter.Composite.allBodies(worldRef.current).filter((b) => !b.isStatic);

      // Sort by fruit tier ascending (clear lower/smaller tier fruits first)
      bodies.sort((a, b) => {
        const tierA = (a as unknown as { fruitTier?: number }).fruitTier || 0;
        const tierB = (b as unknown as { fruitTier?: number }).fruitTier || 0;
        return tierA - tierB;
      });

      const countToRemove = Math.ceil(bodies.length * 0.5);
      const bodiesToRemove = bodies.slice(0, countToRemove);

      bodiesToRemove.forEach((body) => {
        Matter.World.remove(worldRef.current!, body);
        createParticles(body.position.x, body.position.y, '#38BDF8', 12);
      });

      // Reset danger timer
      dangerStartTimeRef.current = null;
      setDangerWarning(false);

      addFloatingText(CONTAINER_WIDTH / 2, CONTAINER_HEIGHT / 2, '✨ 50% CONTAINER CLEARED! ✨', '#38BDF8');
    }
  }, [clearHalfTrigger]);


  // Handle Shake trigger from parent
  useEffect(() => {
    if (shakeTrigger > 0 && worldRef.current) {
      soundManager.playShake();
      const bodies = Matter.Composite.allBodies(worldRef.current);
      bodies.forEach((body) => {
        if (!body.isStatic) {
          const forceX = (Math.random() - 0.5) * 0.08 * body.mass;
          const forceY = -0.09 * body.mass;
          Matter.Body.applyForce(body, body.position, { x: forceX, y: forceY });
        }
      });
      // Particle spray
      for (let i = 0; i < 20; i++) {
        particlesRef.current.push({
          x: CONTAINER_WIDTH / 2 + (Math.random() - 0.5) * 200,
          y: CONTAINER_HEIGHT - 50,
          vx: (Math.random() - 0.5) * 6,
          vy: -Math.random() * 8 - 2,
          radius: Math.random() * 4 + 2,
          color: '#FFB703',
          alpha: 1,
          life: 0,
          maxLife: 30
        });
      }
    }
  }, [shakeTrigger]);

  // Helper: Create particles
  const createParticles = useCallback((x: number, y: number, color: string, count = 15) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: Math.random() * 4 + 2,
        color,
        alpha: 1,
        life: 0,
        maxLife: Math.floor(Math.random() * 20) + 20
      });
    }
  }, []);

  // Helper: Add floating score text
  const addFloatingText = useCallback((x: number, y: number, text: string, color = '#70E000') => {
    floatingTextsRef.current.push({
      id: Math.random().toString(),
      x,
      y,
      text,
      color,
      alpha: 1,
      vy: -1.5
    });
  }, []);

  // Initialize Matter.js Physics Engine
  useEffect(() => {
    const engine = Matter.Engine.create({
      gravity: { x: 0, y: 1.2 }
    });
    const world = engine.world;

    engineRef.current = engine;
    worldRef.current = world;

    // Create Container Boundary Walls (Thick static rectangles)
    const wallOptions = { isStatic: true, restitution: 0.2, friction: 0.3 };
    const leftWall = Matter.Bodies.rectangle(5, CONTAINER_HEIGHT / 2, 20, CONTAINER_HEIGHT, wallOptions);
    const rightWall = Matter.Bodies.rectangle(CONTAINER_WIDTH - 5, CONTAINER_HEIGHT / 2, 20, CONTAINER_HEIGHT, wallOptions);
    const floor = Matter.Bodies.rectangle(CONTAINER_WIDTH / 2, CONTAINER_HEIGHT - 5, CONTAINER_WIDTH, 20, wallOptions);

    Matter.World.add(world, [leftWall, rightWall, floor]);

    // Collision Detection Logic
    const handleCollision = (event: Matter.IEventCollision<Matter.Engine>) => {
      const pairs = event.pairs;

      pairs.forEach((pair) => {
        const bodyA = pair.bodyA;
        const bodyB = pair.bodyB;

        const tierA = (bodyA as unknown as { fruitTier?: number }).fruitTier;
        const tierB = (bodyB as unknown as { fruitTier?: number }).fruitTier;

        // Check if both bodies have valid identical fruit tiers and haven't merged yet
        if (
          tierA !== undefined &&
          tierB !== undefined &&
          tierA === tierB &&
          !(bodyA as unknown as { isMerged?: boolean }).isMerged &&
          !(bodyB as unknown as { isMerged?: boolean }).isMerged
        ) {
          // Mark as merged to prevent duplicate triggers in single frame
          (bodyA as unknown as { isMerged?: boolean }).isMerged = true;
          (bodyB as unknown as { isMerged?: boolean }).isMerged = true;

          const midX = (bodyA.position.x + bodyB.position.x) / 2;
          const midY = (bodyA.position.y + bodyB.position.y) / 2;

          // Remove both merged bodies from physics world
          Matter.World.remove(world, bodyA);
          Matter.World.remove(world, bodyB);

          const currentFruit = getFruitByTier(tierA);

          if (tierA < 10) {
            const nextTier = tierA + 1;
            const nextFruit = getFruitByTier(nextTier);

            // Spawn upgraded fruit at collision midpoint
            const newBody = Matter.Bodies.circle(midX, midY, nextFruit.radius, {
              restitution: 0.2,
              friction: 0.3,
              density: 0.002
            });
            (newBody as unknown as { fruitTier: number }).fruitTier = nextTier;

            Matter.World.add(world, newBody);

            soundManager.playMerge(nextTier);
            createParticles(midX, midY, nextFruit.color, 16);
            addFloatingText(midX, midY, `+${nextFruit.points}`, nextFruit.color);

            onAddScore(nextFruit.points, nextTier);
          } else {
            // Watermelon + Watermelon Merge!
            soundManager.playWatermelon();
            createParticles(midX, midY, '#2EC4B6', 40);
            addFloatingText(midX, midY, '+2048 MAX WATERMELON!', '#2EC4B6');

            onAddScore(2048, 10);
            onWatermelonCreated();
          }
        }
      });
    };

    Matter.Events.on(engine, 'collisionStart', handleCollision);

    return () => {
      Matter.Events.off(engine, 'collisionStart', handleCollision);
      Matter.World.clear(world, false);
      Matter.Engine.clear(engine);
    };
  }, [createParticles, addFloatingText, onAddScore, onWatermelonCreated]);

  // Main Animation & Render Loop
  useEffect(() => {
    let animId: number;

    const renderLoop = () => {
      const canvas = canvasRef.current;
      const engine = engineRef.current;
      const world = worldRef.current;

      if (!canvas || !engine || !world) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // 1. Advance Physics Engine Step
      Matter.Engine.update(engine, 1000 / 60);

      // 2. Clear Canvas & Draw Container
      ctx.clearRect(0, 0, CONTAINER_WIDTH, CONTAINER_HEIGHT);

      // Glassy Container Background
      ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
      ctx.strokeStyle = 'rgba(165, 180, 252, 0.6)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(10, 10, CONTAINER_WIDTH - 20, CONTAINER_HEIGHT - 20, 20);
      ctx.fill();
      ctx.stroke();

      // 3. Danger Line Check & Render
      ctx.setLineDash([6, 6]);
      ctx.strokeStyle = dangerWarning ? 'rgba(239, 68, 68, 0.9)' : 'rgba(239, 68, 68, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(15, DANGER_Y);
      ctx.lineTo(CONTAINER_WIDTH - 15, DANGER_Y);
      ctx.stroke();
      ctx.setLineDash([]);

      if (dangerWarning) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText('⚠️ DANGER!', CONTAINER_WIDTH - 25, DANGER_Y - 6);
      }

      // Check overflow danger condition
      const allBodies = Matter.Composite.allBodies(world);
      let isOverflowing = false;

      allBodies.forEach((body) => {
        const fruitTier = (body as unknown as { fruitTier?: number }).fruitTier;
        if (fruitTier !== undefined && !body.isStatic) {
          const topEdge = body.position.y - getFruitByTier(fruitTier).radius;
          // Check if settled or slow body is above danger line
          if (topEdge < DANGER_Y && Math.abs(body.velocity.y) < 0.5) {
            isOverflowing = true;
          }
        }
      });

      if (isOverflowing && !isGameOver) {
        if (!dangerStartTimeRef.current) {
          dangerStartTimeRef.current = Date.now();
          setDangerWarning(true);
        } else if (Date.now() - dangerStartTimeRef.current > 2500) {
          // Sustained danger line violation -> Trigger Game Over!
          soundManager.playGameOver();
          onGameOver();
        }
      } else {
        dangerStartTimeRef.current = null;
        setDangerWarning(false);
      }

      // 4. Render All Physics Fruit Bodies
      allBodies.forEach((body) => {
        const fruitTier = (body as unknown as { fruitTier?: number }).fruitTier;
        if (fruitTier !== undefined) {
          const config = getFruitByTier(fruitTier);
          drawFruitOnCanvas(ctx, body.position.x, body.position.y, config.radius, body.angle, config);
        }
      });

      // 5. Render Active Ready Fruit on Top Holder & Guide Line (if not in game over / cooldown)
      if (!isGameOver) {
        const currentFruit = getFruitByTier(currentTier);
        const clampedX = Math.max(
          15 + currentFruit.radius,
          Math.min(CONTAINER_WIDTH - 15 - currentFruit.radius, pointerX)
        );

        // Dashed Drop Guide Line
        ctx.setLineDash([4, 6]);
        ctx.strokeStyle = activePowerUp ? 'rgba(236, 72, 153, 0.6)' : 'rgba(99, 102, 241, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(clampedX, HOLDER_Y);
        ctx.lineTo(clampedX, CONTAINER_HEIGHT - 15);
        ctx.stroke();
        ctx.setLineDash([]);

        // Ready Fruit on Holder
        if (!isCooldown) {
          drawFruitOnCanvas(ctx, clampedX, HOLDER_Y, currentFruit.radius, 0, currentFruit, 0.95);
        }
      }

      // 6. Render Particles
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        p.alpha = 1 - p.life / p.maxLife;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;

        if (p.life >= p.maxLife) {
          particlesRef.current.splice(i, 1);
        }
      }

      // 7. Render Floating Text
      for (let i = floatingTextsRef.current.length - 1; i >= 0; i--) {
        const ft = floatingTextsRef.current[i];
        ft.y += ft.vy;
        ft.alpha -= 0.02;

        ctx.font = 'black 14px sans-serif';
        ctx.fillStyle = ft.color;
        ctx.textAlign = 'center';
        ctx.globalAlpha = Math.max(0, ft.alpha);
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.globalAlpha = 1;

        if (ft.alpha <= 0) {
          floatingTextsRef.current.splice(i, 1);
        }
      }

      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(animId);
  }, [pointerX, isCooldown, currentTier, dangerWarning, isGameOver, activePowerUp, onGameOver]);

  // Pointer position tracking (Mouse & Touch)
  const updatePointerFromEvent = (clientX: number) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const relativeX = (clientX - rect.left) * (CONTAINER_WIDTH / rect.width);
    setPointerX(relativeX);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    updatePointerFromEvent(e.clientX);
  };

  // Handle Canvas Click / Tap (Drop fruit or Use Power-up)
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isGameOver || !canvasRef.current || !worldRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = (e.clientX - rect.left) * (CONTAINER_WIDTH / rect.width);
    const clickY = (e.clientY - rect.top) * (CONTAINER_HEIGHT / rect.height);

    // Power-Up Mode 1: BOMB
    if (activePowerUp === 'bomb') {
      soundManager.playBomb();
      const bodies = Matter.Composite.allBodies(worldRef.current);

      bodies.forEach((body) => {
        if (!body.isStatic) {
          const dx = body.position.x - clickX;
          const dy = body.position.y - clickY;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 110) {
            // Destroy fruits inside detonation radius
            Matter.World.remove(worldRef.current!, body);
            createParticles(body.position.x, body.position.y, '#EF4444', 15);
          } else if (dist < 200) {
            // Push surrounding fruits outward
            const forceMag = 0.1 * body.mass;
            Matter.Body.applyForce(body, body.position, {
              x: (dx / dist) * forceMag,
              y: (dy / dist) * forceMag
            });
          }
        }
      });

      createParticles(clickX, clickY, '#F59E0B', 30);
      addFloatingText(clickX, clickY, 'BOOM!', '#EF4444');
      onConsumePowerUp('bomb');
      return;
    }

    // Power-Up Mode 2: UPGRADE WAND
    if (activePowerUp === 'upgrade') {
      const bodies = Matter.Composite.allBodies(worldRef.current);
      let upgraded = false;

      for (let i = 0; i < bodies.length; i++) {
        const body = bodies[i];
        const tier = (body as unknown as { fruitTier?: number }).fruitTier;

        if (tier !== undefined && !body.isStatic) {
          const dx = body.position.x - clickX;
          const dy = body.position.y - clickY;
          const config = getFruitByTier(tier);

          if (Math.sqrt(dx * dx + dy * dy) <= config.radius && tier < 10) {
            const nextTier = tier + 1;
            const nextConfig = getFruitByTier(nextTier);

            Matter.World.remove(worldRef.current, body);

            const newBody = Matter.Bodies.circle(body.position.x, body.position.y, nextConfig.radius, {
              restitution: 0.2,
              friction: 0.3
            });
            (newBody as unknown as { fruitTier: number }).fruitTier = nextTier;

            Matter.World.add(worldRef.current, newBody);

            soundManager.playMerge(nextTier);
            createParticles(body.position.x, body.position.y, nextConfig.color, 20);
            addFloatingText(body.position.x, body.position.y, 'LEVEL UP!', nextConfig.color);

            onConsumePowerUp('upgrade');
            upgraded = true;
            break;
          }
        }
      }
      if (upgraded) return;
    }

    // Standard Drop Action
    if (isCooldown) return;

    const currentFruit = getFruitByTier(currentTier);
    const clampedX = Math.max(
      15 + currentFruit.radius,
      Math.min(CONTAINER_WIDTH - 15 - currentFruit.radius, pointerX)
    );

    // Create & Spawn Fruit Physics Body
    const fruitBody = Matter.Bodies.circle(clampedX, HOLDER_Y, currentFruit.radius, {
      restitution: 0.2,
      friction: 0.3,
      density: 0.002
    });
    (fruitBody as unknown as { fruitTier: number }).fruitTier = currentTier;

    Matter.World.add(worldRef.current, fruitBody);
    soundManager.playDrop();

    // Trigger Cooldown & Advance Next Fruit
    setIsCooldown(true);
    const newNextTier = getRandomSpawnTier();
    onDropDone(newNextTier);

    setTimeout(() => {
      setIsCooldown(false);
    }, 450);
  };

  return (
    <div ref={containerRef} className="w-full flex flex-col items-center select-none py-1 relative">
      <div className="relative rounded-3xl overflow-hidden shadow-xl border-4 border-white/80 bg-gradient-to-b from-indigo-50/80 to-purple-100/80 backdrop-blur-md">
        <canvas
          ref={canvasRef}
          width={CONTAINER_WIDTH}
          height={CONTAINER_HEIGHT}
          onPointerMove={handlePointerMove}
          onClick={handleCanvasClick}
          className="cursor-crosshair touch-none max-w-full h-auto block"
        />

        {/* Danger Emergency Rescue Badge */}
        {dangerWarning && onTriggerAdRescue && !isGameOver && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 animate-bounce">
            <button
              onClick={onTriggerAdRescue}
              className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-white text-xs font-black px-4 py-2 rounded-full shadow-lg shadow-amber-500/40 border-2 border-white flex items-center gap-1.5 cursor-pointer hover:scale-105 transition-transform"
              id="btn-trigger-rescue-ad"
            >
              <span className="text-sm">🎬</span>
              <span>Watch Ad to Clear 50% Fruits!</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

