import React, { useEffect, useState } from 'react';
import { Play, CheckCircle2, Sparkles, X, ShieldAlert, Bomb, RefreshCw } from 'lucide-react';
import { AdType } from '../types';

interface AdModalProps {
  isOpen: boolean;
  type: AdType;
  onClose: (completedReward: boolean) => void;
}

export const AdModal: React.FC<AdModalProps> = ({ isOpen, type, onClose }) => {
  const [countdown, setCountdown] = useState<number>(5);
  const [canSkip, setCanSkip] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setCountdown(5);
      setCanSkip(false);

      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setCanSkip(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaim = () => {
    onClose(true);
  };

  const isRewarded = type !== 'timed_interstitial';

  const getAdInfo = () => {
    switch (type) {
      case 'rewarded_bomb':
        return {
          icon: <Bomb className="w-8 h-8 text-rose-400" />,
          title: 'Unlock Bomb Power-Up! 💣',
          desc: 'Watch this quick video ad to get a Bomb power-up and detonate any unwanted fruit!',
          btnText: 'Claim Bomb Power-Up'
        };
      case 'rewarded_shake':
        return {
          icon: <RefreshCw className="w-8 h-8 text-amber-400" />,
          title: 'Unlock Container Shake! 🔄',
          desc: 'Watch this quick video ad to shake the container and shuffle trapped fruits!',
          btnText: 'Claim Shake Power-Up'
        };
      case 'rewarded_upgrade':
        return {
          icon: <Sparkles className="w-8 h-8 text-purple-400" />,
          title: 'Unlock Level-Up Wand! ✨',
          desc: 'Watch this quick video ad to get a Level-Up Wand and directly evolve any fruit!',
          btnText: 'Claim Level-Up Wand'
        };
      case 'rescue_clear_half':
        return {
          icon: <ShieldAlert className="w-8 h-8 text-amber-400" />,
          title: 'Emergency Rescue Activated! 🚨',
          desc: 'Watch this ad to clear 50% of the lowest fruits from your container and continue playing!',
          btnText: 'Clear 50% Fruits Now'
        };
      case 'timed_interstitial':
      default:
        return {
          icon: <Sparkles className="w-8 h-8 text-pink-400" />,
          title: 'Suika Game Special Offer',
          desc: 'Thank you for playing Suika Merge! Enjoy your game session.',
          btnText: 'Continue Playing'
        };
    }
  };

  const adInfo = getAdInfo();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in select-none">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center text-white relative overflow-hidden">
        {/* Top AdMob Header */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-[11px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
              AdMob Video Ad
            </span>
            <span className="text-xs font-semibold text-slate-400">
              {isRewarded ? 'Rewarded Ad' : 'Interstitial Ad'}
            </span>
          </div>

          {canSkip && (
            <button
              onClick={() => onClose(true)}
              className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Close Ad"
              id="btn-close-ad"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Video Simulation Box */}
        <div className="w-full aspect-video bg-gradient-to-tr from-indigo-900 via-purple-900 to-pink-800 rounded-2xl p-4 flex flex-col items-center justify-center shadow-inner relative overflow-hidden my-2 border border-slate-700/60">
          <div className="w-14 h-14 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mb-2 animate-bounce">
            {adInfo.icon}
          </div>

          <h3 className="text-lg font-black text-white">{adInfo.title}</h3>

          <p className="text-xs text-slate-200 mt-1 max-w-xs">{adInfo.desc}</p>

          {/* Ad Timer Badge */}
          <div className="mt-3 bg-slate-950/70 backdrop-blur-md px-3 py-1 rounded-full border border-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5">
            {countdown > 0 ? (
              <>
                <Play className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>Ad reward in {countdown}s...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ad Complete!</span>
              </>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="w-full mt-4">
          {countdown > 0 ? (
            <div className="w-full py-3.5 rounded-2xl bg-slate-800 text-slate-400 font-bold text-sm cursor-not-allowed">
              Please wait {countdown} seconds...
            </div>
          ) : (
            <button
              onClick={handleClaim}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 text-white font-extrabold text-base shadow-lg shadow-emerald-900/40 hover:shadow-emerald-900/60 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              id="btn-claim-ad-reward"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-200" />
              <span>{adInfo.btnText}</span>
            </button>
          )}
        </div>

        <span className="text-[10px] text-slate-500 mt-3 font-medium font-mono">
          AdMob Unit: {isRewarded ? 'ca-app-pub-7810800944989675/2484959425' : 'ca-app-pub-7810800944989675/5111122762'}
        </span>
      </div>
    </div>
  );
};
