import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Flame, Sparkles } from 'lucide-react';
import { GameStats } from '../types';

interface GameOverModalProps {
  isOpen: boolean;
  stats: GameStats;
  onRestart: () => void;
  onWatchAdRescue?: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  stats,
  onRestart,
  onWatchAdRescue
}) => {
  useEffect(() => {
    if (isOpen) {
      // Fire celebratory confetti!
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isNewHighScore = stats.score >= stats.highScore && stats.score > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fade-in select-none">
      <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-purple-100 flex flex-col items-center text-center transform transition-all scale-100">
        {/* Top Fruit Icon / Trophy */}
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-pink-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-pink-200 mb-3 text-3xl">
          🍉
        </div>

        <h2 className="text-2xl font-black text-slate-800">Container Full!</h2>
        <p className="text-xs font-semibold text-slate-500 mt-0.5">The fruits crossed the danger line!</p>

        {/* High Score Notification */}
        {isNewHighScore && (
          <div className="mt-3 bg-amber-100 text-amber-900 text-xs font-bold px-3 py-1 rounded-full border border-amber-300 flex items-center gap-1.5 animate-bounce">
            <Trophy className="w-4 h-4 text-amber-600" />
            <span>New High Score Record!</span>
          </div>
        )}

        {/* Main Score Box */}
        <div className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 my-4 flex flex-col items-center">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Final Score</span>
          <span className="text-4xl font-black text-indigo-600 mt-1">{stats.score}</span>

          <div className="w-full grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200/60 text-left">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400">Total Merges</span>
              <span className="text-sm font-black text-slate-700 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                {stats.mergesCount}
              </span>
            </div>

            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400">Watermelons</span>
              <span className="text-sm font-black text-slate-700 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                {stats.watermelonsCreated}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          {onWatchAdRescue && (
            <button
              onClick={onWatchAdRescue}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white font-extrabold text-sm shadow-md shadow-amber-200 hover:shadow-amber-300 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 cursor-pointer border border-amber-300"
              id="btn-ad-rescue-gameover"
            >
              <span className="text-base">🎬</span>
              <span>Watch Ad to Clear 50% & Rescue!</span>
            </button>
          )}

          <button
            onClick={onRestart}
            className="w-full py-3.5 px-6 rounded-2xl bg-slate-900 text-white font-extrabold text-sm shadow-lg shadow-slate-200 hover:bg-slate-800 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            id="btn-restart-game"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart New Game</span>
          </button>
        </div>
      </div>
    </div>
  );
};

