import React from 'react';
import { Volume2, VolumeX, Bomb, RefreshCw, Sparkles, Trophy, Flame } from 'lucide-react';
import { PowerUpType } from '../types';
import { getFruitByTier } from '../utils/fruitData';

interface TopBarProps {
  score: number;
  highScore: number;
  nextTier: number;
  isMuted: boolean;
  onToggleMute: () => void;
  activePowerUp: PowerUpType;
  onSelectPowerUp: (type: PowerUpType) => void;
  onRequestAdPowerUp: (type: 'rewarded_bomb' | 'rewarded_shake' | 'rewarded_upgrade') => void;
  powerUpCounts: { bomb: number; shake: number; upgrade: number };
  watermelonsCreated: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  score,
  highScore,
  nextTier,
  isMuted,
  onToggleMute,
  activePowerUp,
  onSelectPowerUp,
  onRequestAdPowerUp,
  powerUpCounts,
  watermelonsCreated
}) => {
  const nextFruit = getFruitByTier(nextTier);

  const handleToolClick = (type: PowerUpType, adType: 'rewarded_bomb' | 'rewarded_shake' | 'rewarded_upgrade') => {
    if (!type) return;
    const count = powerUpCounts[type];
    if (count > 0) {
      onSelectPowerUp(activePowerUp === type ? null : type);
    } else {
      onRequestAdPowerUp(adType);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-2 flex flex-col gap-2 select-none">
      {/* Upper row: Header title & controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🍉</span>
          <h1 className="text-xl sm:text-2xl font-extrabold bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
            Suika Merge
          </h1>
          {watermelonsCreated > 0 && (
            <div className="flex items-center gap-1 bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded-full border border-amber-300">
              <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>x{watermelonsCreated}</span>
            </div>
          )}
        </div>

        <button
          onClick={onToggleMute}
          className="p-2 rounded-xl bg-white/80 hover:bg-white text-slate-700 shadow-sm border border-slate-200 transition-transform active:scale-95 cursor-pointer"
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          id="btn-sound-toggle"
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-slate-400" /> : <Volume2 className="w-5 h-5 text-indigo-600" />}
        </button>
      </div>

      {/* Middle row: Score Cards & Next Fruit Badge */}
      <div className="grid grid-cols-3 gap-2 items-center">
        {/* Score Card */}
        <div className="bg-white/90 backdrop-blur-sm p-2 rounded-2xl border border-purple-100 shadow-sm flex flex-col items-center">
          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600">Score</span>
          <span className="text-lg sm:text-xl font-black text-slate-800 leading-tight">{score}</span>
        </div>

        {/* High Score Card */}
        <div className="bg-white/90 backdrop-blur-sm p-2 rounded-2xl border border-amber-100 shadow-sm flex flex-col items-center">
          <div className="flex items-center gap-1">
            <Trophy className="w-3 h-3 text-amber-500" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600">Best</span>
          </div>
          <span className="text-lg sm:text-xl font-black text-slate-800 leading-tight">{highScore}</span>
        </div>

        {/* Next Fruit Preview */}
        <div className="bg-white/90 backdrop-blur-sm p-2 rounded-2xl border border-pink-100 shadow-sm flex flex-col items-center justify-center">
          <span className="text-[10px] font-bold uppercase tracking-wider text-pink-600">Next</span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-xs shadow-inner"
              style={{ backgroundColor: nextFruit.color }}
            />
            <span className="text-xs font-bold text-slate-700 truncate max-w-[65px]">{nextFruit.name}</span>
          </div>
        </div>
      </div>

      {/* Lower row: Power-up Tools Bar */}
      <div className="flex items-center justify-center gap-2 sm:gap-3 bg-white/80 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-indigo-100 shadow-sm flex-wrap">
        <span className="text-xs font-bold text-slate-500 mr-0.5">Tools:</span>

        {/* Bomb Powerup */}
        <button
          onClick={() => handleToolClick('bomb', 'rewarded_bomb')}
          id="btn-powerup-bomb"
          className={`relative px-2.5 py-1 rounded-xl flex items-center gap-1 text-xs font-bold transition-all cursor-pointer ${
            activePowerUp === 'bomb'
              ? 'bg-rose-500 text-white shadow-md shadow-rose-200 scale-105 ring-2 ring-rose-400'
              : powerUpCounts.bomb > 0
              ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
              : 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse'
          }`}
          title={powerUpCounts.bomb > 0 ? 'Use Bomb' : 'Watch Ad for Bomb'}
        >
          <Bomb className="w-3.5 h-3.5 text-rose-600" />
          <span>Bomb</span>
          {powerUpCounts.bomb > 0 ? (
            <span className="ml-0.5 px-1.5 py-0.2 bg-white/80 text-rose-800 rounded-full text-[10px] font-extrabold">
              {powerUpCounts.bomb}
            </span>
          ) : (
            <span className="ml-0.5 px-1.5 py-0.2 bg-amber-400 text-slate-950 rounded-full text-[9px] font-black uppercase">
              🎬 Ad
            </span>
          )}
        </button>

        {/* Shake Container Powerup */}
        <button
          onClick={() => handleToolClick('shake', 'rewarded_shake')}
          id="btn-powerup-shake"
          className={`relative px-2.5 py-1 rounded-xl flex items-center gap-1 text-xs font-bold transition-all cursor-pointer ${
            powerUpCounts.shake > 0
              ? 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 active:scale-95'
              : 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse'
          }`}
          title={powerUpCounts.shake > 0 ? 'Use Shake' : 'Watch Ad for Shake'}
        >
          <RefreshCw className="w-3.5 h-3.5 text-amber-600" />
          <span>Shake</span>
          {powerUpCounts.shake > 0 ? (
            <span className="ml-0.5 px-1.5 py-0.2 bg-white/80 text-amber-800 rounded-full text-[10px] font-extrabold">
              {powerUpCounts.shake}
            </span>
          ) : (
            <span className="ml-0.5 px-1.5 py-0.2 bg-amber-400 text-slate-950 rounded-full text-[9px] font-black uppercase">
              🎬 Ad
            </span>
          )}
        </button>

        {/* Upgrade Wand Powerup */}
        <button
          onClick={() => handleToolClick('upgrade', 'rewarded_upgrade')}
          id="btn-powerup-upgrade"
          className={`relative px-2.5 py-1 rounded-xl flex items-center gap-1 text-xs font-bold transition-all cursor-pointer ${
            activePowerUp === 'upgrade'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-200 scale-105 ring-2 ring-purple-400'
              : powerUpCounts.upgrade > 0
              ? 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200'
              : 'bg-purple-100 text-purple-800 border border-purple-300 animate-pulse'
          }`}
          title={powerUpCounts.upgrade > 0 ? 'Use Level Up' : 'Watch Ad for Level Up'}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-600" />
          <span>Level Up</span>
          {powerUpCounts.upgrade > 0 ? (
            <span className="ml-0.5 px-1.5 py-0.2 bg-white/80 text-purple-800 rounded-full text-[10px] font-extrabold">
              {powerUpCounts.upgrade}
            </span>
          ) : (
            <span className="ml-0.5 px-1.5 py-0.2 bg-amber-400 text-slate-950 rounded-full text-[9px] font-black uppercase">
              🎬 Ad
            </span>
          )}
        </button>
      </div>

      {activePowerUp && (
        <div className="text-center text-xs font-bold bg-indigo-600 text-white py-1 px-3 rounded-full animate-pulse shadow-sm">
          {activePowerUp === 'bomb' && '💣 Click on any fruit in the box to detonate!'}
          {activePowerUp === 'upgrade' && '✨ Click on any fruit to evolve it to the next level!'}
        </div>
      )}
    </div>
  );
};
