import { useState, useEffect, useCallback } from 'react';
import { TopBar } from './components/TopBar';
import { EvolutionBar } from './components/EvolutionBar';
import { FruitCanvas } from './components/FruitCanvas';
import { GameOverModal } from './components/GameOverModal';
import { AdBanner } from './components/AdBanner';
import { AdModal } from './components/AdModal';
import { getRandomSpawnTier } from './utils/fruitData';
import { soundManager } from './utils/audio';
import { PowerUpType, GameStats, AdType } from './types';

export default function App() {
  // Fruit Queue state
  const [currentTier, setCurrentTier] = useState<number>(getRandomSpawnTier());
  const [nextTier, setNextTier] = useState<number>(getRandomSpawnTier());

  // Game Stats
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('suika_high_score');
      return saved ? parseInt(saved, 10) : 0;
    }
    return 0;
  });
  const [mergesCount, setMergesCount] = useState<number>(0);
  const [watermelonsCreated, setWatermelonsCreated] = useState<number>(0);

  // Power-Ups & Clear 50%
  const [activePowerUp, setActivePowerUp] = useState<PowerUpType>(null);
  const [powerUpCounts, setPowerUpCounts] = useState({
    bomb: 2,
    shake: 3,
    upgrade: 1
  });
  const [shakeTrigger, setShakeTrigger] = useState<number>(0);
  const [clearHalfTrigger, setClearHalfTrigger] = useState<number>(0);

  // Audio state
  const [isMuted, setIsMuted] = useState<boolean>(soundManager.getMuted());

  // Game Over modal
  const [isGameOver, setIsGameOver] = useState<boolean>(false);

  // AdMob & Timed Ads System (5 min first ad = 300s, then 4 min = 240s)
  const [playTimeSeconds, setPlayTimeSeconds] = useState<number>(0);
  const [nextAdCountdown, setNextAdCountdown] = useState<number>(300); // 5 mins
  const [isFirstAdTriggered, setIsFirstAdTriggered] = useState<boolean>(false);
  const [adModal, setAdModal] = useState<{ isOpen: boolean; type: AdType }>({
    isOpen: false,
    type: null
  });

  // Playtime Timer (Runs every second unless game over or ad modal open)
  useEffect(() => {
    if (isGameOver || adModal.isOpen) return;

    const timer = setInterval(() => {
      setPlayTimeSeconds((prev) => prev + 1);

      setNextAdCountdown((prev) => {
        if (prev <= 1) {
          // Trigger Timed Interstitial Ad!
          setAdModal({ isOpen: true, type: 'timed_interstitial' });

          // Next ad target interval: 4 minutes (240 seconds)
          if (!isFirstAdTriggered) {
            setIsFirstAdTriggered(true);
          }
          return 240; // 4 mins
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isGameOver, adModal.isOpen, isFirstAdTriggered]);

  // High score sync
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem('suika_high_score', score.toString());
    }
  }, [score, highScore]);

  // Handlers
  const handleDropDone = useCallback((newNextTier: number) => {
    setCurrentTier(nextTier);
    setNextTier(newNextTier);
  }, [nextTier]);

  const handleAddScore = useCallback((points: number) => {
    setScore((prev) => prev + points);
    setMergesCount((prev) => prev + 1);
  }, []);

  const handleWatermelonCreated = useCallback(() => {
    setWatermelonsCreated((prev) => prev + 1);
    setPowerUpCounts((prev) => ({
      ...prev,
      bomb: prev.bomb + 1
    }));
  }, []);

  const handleSelectPowerUp = (type: PowerUpType) => {
    if (type === 'shake') {
      if (powerUpCounts.shake > 0) {
        setPowerUpCounts((prev) => ({ ...prev, shake: prev.shake - 1 }));
        setShakeTrigger((prev) => prev + 1);
      }
      setActivePowerUp(null);
    } else {
      setActivePowerUp(type);
    }
  };

  const handleConsumePowerUp = (type: PowerUpType) => {
    if (type && powerUpCounts[type] > 0) {
      setPowerUpCounts((prev) => ({
        ...prev,
        [type]: Math.max(0, prev[type] - 1)
      }));
    }
    setActivePowerUp(null);
  };

  const handleToggleMute = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
  };

  const handleGameOver = useCallback(() => {
    setIsGameOver(true);
  }, []);

  // Open Ad Modal for Power-Ups or Emergency Rescue
  const handleTriggerAdRescue = () => {
    setAdModal({ isOpen: true, type: 'rescue_clear_half' });
  };

  const handleRequestAdPowerUp = (type: 'rewarded_bomb' | 'rewarded_shake' | 'rewarded_upgrade') => {
    setAdModal({ isOpen: true, type });
  };

  // Close Ad Modal Callback
  const handleCloseAdModal = (completedReward: boolean) => {
    const currentAdType = adModal.type;
    setAdModal({ isOpen: false, type: null });

    if (completedReward) {
      if (currentAdType === 'rescue_clear_half') {
        setIsGameOver(false);
        setClearHalfTrigger((prev) => prev + 1);
      } else if (currentAdType === 'rewarded_bomb') {
        setPowerUpCounts((prev) => ({ ...prev, bomb: prev.bomb + 1 }));
        setActivePowerUp('bomb');
      } else if (currentAdType === 'rewarded_shake') {
        setPowerUpCounts((prev) => ({ ...prev, shake: prev.shake + 1 }));
        setShakeTrigger((prev) => prev + 1);
      } else if (currentAdType === 'rewarded_upgrade') {
        setPowerUpCounts((prev) => ({ ...prev, upgrade: prev.upgrade + 1 }));
        setActivePowerUp('upgrade');
      }
    }
  };

  const handleRestart = () => {
    setIsGameOver(false);
    setScore(0);
    setMergesCount(0);
    setWatermelonsCreated(0);
    setPowerUpCounts({ bomb: 1, shake: 1, upgrade: 1 });
    setActivePowerUp(null);
    setCurrentTier(getRandomSpawnTier());
    setNextTier(getRandomSpawnTier());
  };

  const gameStats: GameStats = {
    score,
    highScore,
    mergesCount,
    fruitCounts: {},
    watermelonsCreated
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 flex flex-col justify-between items-center py-2 px-3 font-sans antialiased select-none overflow-x-hidden">
      {/* Top AdMob Banner Slot */}
      <AdBanner position="top" adSlotId="ca-app-pub-7810800944989675/2554860150" />

      {/* Top Status & Controls */}
      <TopBar
        score={score}
        highScore={highScore}
        nextTier={nextTier}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        activePowerUp={activePowerUp}
        onSelectPowerUp={handleSelectPowerUp}
        onRequestAdPowerUp={handleRequestAdPowerUp}
        powerUpCounts={powerUpCounts}
        watermelonsCreated={watermelonsCreated}
      />

      {/* Main Physics Canvas Game Stage */}
      <FruitCanvas
        currentTier={currentTier}
        nextTier={nextTier}
        onDropDone={handleDropDone}
        onAddScore={handleAddScore}
        onWatermelonCreated={handleWatermelonCreated}
        onGameOver={handleGameOver}
        activePowerUp={activePowerUp}
        onConsumePowerUp={handleConsumePowerUp}
        shakeTrigger={shakeTrigger}
        clearHalfTrigger={clearHalfTrigger}
        onTriggerAdRescue={handleTriggerAdRescue}
        isGameOver={isGameOver}
      />

      {/* Evolution Chain Banner */}
      <EvolutionBar currentDropTier={currentTier} />

      {/* Bottom AdMob Banner Slot */}
      <AdBanner position="bottom" adSlotId="ca-app-pub-7810800944989675/2554860150" />

      {/* Game Over Modal */}
      <GameOverModal
        isOpen={isGameOver}
        stats={gameStats}
        onRestart={handleRestart}
        onWatchAdRescue={handleTriggerAdRescue}
      />

      {/* Fullscreen AdMob Video Interstitial / Rewarded Modal */}
      <AdModal
        isOpen={adModal.isOpen}
        type={adModal.type}
        onClose={handleCloseAdModal}
      />
    </div>
  );
}

