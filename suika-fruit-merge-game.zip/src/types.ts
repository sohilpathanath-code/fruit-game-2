export interface FruitConfig {
  tier: number;
  name: string;
  radius: number;
  points: number;
  color: string;
  secondaryColor: string;
  darkColor: string;
  faceType: 'cherry' | 'happy' | 'wink' | 'cute' | 'cool' | 'big_eyes' | 'surprised' | 'star_eyes' | 'yummy' | 'king';
  features?: {
    hasSeeds?: boolean;
    hasStripes?: boolean;
    hasLeaves?: boolean;
    hasStem?: boolean;
    hasCrown?: boolean;
    hasTextureDots?: boolean;
  };
}

export type PowerUpType = 'bomb' | 'shake' | 'upgrade' | null;

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
}

export interface GameStats {
  score: number;
  highScore: number;
  mergesCount: number;
  fruitCounts: Record<number, number>;
  watermelonsCreated: number;
}

export type AdType = 'timed_interstitial' | 'rescue_clear_half' | 'rewarded_bomb' | 'rewarded_shake' | 'rewarded_upgrade' | null;

export interface AdState {
  isOpen: boolean;
  type: AdType;
  countdown: number;
  canSkip: boolean;
  title: string;
  rewardDescription: string;
}

